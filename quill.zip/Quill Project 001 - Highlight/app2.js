// #################################################################################
//                                                                             TABS
// #################################################################################

/** See: https://www.w3schools.com/howto/howto_js_tabs.asp */
function openTab(evt, tabName) {
  // Declare all variables
  var i, tabcontent, tabButtons;

  // Get all elements with class="tabcontent" and hide them
  tabcontent = document.getElementsByClassName("tab-content");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }

  // Get all elements with class="tab-button" and remove the class "active"
  tabButtons = document.getElementsByClassName("tab-button");
  for (i = 0; i < tabButtons.length; i++) {
    tabButtons[i].className = tabButtons[i].className.replace(" active", "");
  }

  // Show the current tab, and add an "active" class to the button that opened the tab
  let openTabContent = document.getElementById(tabName);
  openTabContent.style.display = "block";
  evt.currentTarget.className += " active";

  updateOpenTab(openTabContent);
}

//_------------------------------

var roleShow = false;

const searchKey = "吕树";

function escapeRegExp(string) {
  return string.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
const roleKey = new RegExp(escapeRegExp(searchKey), "gi");

function toRole() {
  const totalText = quill.getText();
  while ((match = roleKey.exec(totalText)) !== null) {
    // 目标文本在文档中的位置
    let index = match.index;
    // 计算 从最初到 index 有多少个特殊 insert
    // index = this.countSpecial(index, searchKey.length);
    console.log("index= " + index + quill.getText(index, searchKey.length));
    if (roleShow) {
      quill.removeFormat(index, searchKey.length);
    } else {
      // 来自于 formatText 的方法, 使其高亮, 第 0 个默认选中
      quill.formatText(index, searchKey.length, "color", "red");
      quill.formatText(index, searchKey.length, "texthighlight", 4);
    }
  }

  //改变文本后,再次搜索keystring时的结果 会不一致,所以要统一修改状态
  roleShow = !roleShow;
}

//-------------------------------

var speechShow = false;

var pat = /[\“](.*?)[\”]/gi;
var r = /[“](.*)[”]/;

function toSpeech() {
  console.log("-----speech");
  const totalText = quill.getText();
  while ((match = pat.exec(totalText)) !== null) {
    // 目标文本在文档中的位置
    let index = match.index + 1;
    const offset = match[0].length - 2;
    // 计算 从最初到 index 有多少个特殊 insert
    // index = this.countSpecial(index, searchKey.length);
    console.log("index= " + index + quill.getText(index, offset));
    if (speechShow) {
      quill.removeFormat(index, offset);
    } else {
      // 来自于 formatText 的方法, 使其高亮, 第 0 个默认选中
      quill.formatText(index, offset, "color", "blue");
      quill.formatText(index, offset, "texthighlight", 2);
    }
  }

  //改变文本后,再次搜索keystring时的结果 会不一致,所以要统一修改状态
  speechShow = !speechShow;
}

function toId() {
  quill.setContents([
    {
      insert: "World!",
      attributes: {
        bold: true,
        color: "red",
        font: "ubuntu",
        size: "50px",
        id: 300,
        cv: "phoenix",
        role: "吕布",
        light: "1",
      },
    },
  ]);
}

function toBlot() {
  const delta = quill.getContents(
    quill.getSelection().index,
    quill.getSelection().length
  );
  alert(
    "id= " +
      delta.ops[0].attributes.id +
      " - " +
      delta.ops[0].attributes.cv +
      " - " +
      delta.ops[0].attributes.role +
      " - " +
      delta.ops[0].attributes.light
  );
}

function toFree() {
  quill.insertEmbed(
    quill.getSelection().index || 0,
    "AppPanelEmbed",
    `
          <div id='100'>     
              自定义面板标题
          </div>
      `
  );
}

function toRed() {
  const range = quill.getSelection();
  var text = quill.getText(range.index, range.length);
  quill.format("color", "red");
}
function toStrike() {
  const range = quill.getSelection();
  var text = quill.getText(range.index, range.length);
  quill.format("strike", true);
}
function toClean() {
  const range = quill.getSelection();
  quill.removeFormat(range.index, range.length);
}

/**
    1 -> 角色
    2 -> CV 
    3 -> 角色-CV
    4 -> CV-角色
**/

const titles = [
  [],
  ["吕树", "phoenix", "吕树-phoenix", "phoenix-吕树"],
  ["吕布", "ken", "吕布-ken", "ken-吕布"],
//   ["吕洞宾","jack","吕洞宾-jack","jack-吕洞宾"]
];
const teams = [
  {
    id: "1",
    role: "吕树",
    cv: "phoenix",
    light: 1,
    color: "red",
  },
  {
    id: "2",
    role: "吕布",
    cv: "ken",
    light: 2,
    color: "blue",
  },
];

const roles = ["吕树", "吕它"];
const orz = [
  { role: "吕树", cv: "phoenix" },
  { role: "吕它", cv: "phoenix" },
];



function loopCheckAnchor(){
    let appendOffset = 0;

  const totalText = quill.getText();
  while ((match = pat.exec(totalText)) !== null) {
    // 目标文本在文档中的位置
    let index = match.index;
    const offset = match[0].length - 2;
    // 计算 从最初到 index 有多少个特殊 insert
    // index = this.countSpecial(index, searchKey.length);
    const delta = quill.getContents(index + appendOffset, offset);

    if (delta.ops[0].attributes) {
      const anchorType = delta.ops[0].attributes.anchor;
      //todo:append
      const idString = delta.ops[0].attributes.id;
      const id=parseInt(idString)

      if (anchorType === "0") {
        const appendContent = titles[id][tooltip.showAnchor - 1];

        appendOffset += tooltip.createAnchorById(
          teams,
          id,
          tooltip.showAnchor,
          index + appendOffset,
          offset,
          appendContent
        );
      } else {
        if (anchorType != tooltip.showAnchor.toString()) {
          // quill.insertEmbed(index+appendOffset,'anchor','666')
          
          quill.getFormat(index+appendOffset)
         quill.formatText(index+appendOffset, offset, 'anchor', '9999');  
          // quill.updateContents([
          //   // {retain: index+appendOffs
          //   {retain:offset,'anchor':tooltip.showAnchor.toString()}
          // ]);
          const anchorDelta = quill.getLeaf(index - 1 + appendOffset);
          const existTextLength = anchorDelta[0].text.length;
          const startIndex = index+appendOffset - anchorDelta[1];
          const content ='['+ titles[id][tooltip.showAnchor - 1]+']';
          const existContent = anchorDelta[0].text;
          quill.updateContents([
            { retain: startIndex - 1},
            { insert:  content },
            { delete: existTextLength },
          ]);
          appendOffset += content.length - existContent.length;
        }
      }
    }
  }
}

function toAnchorOne() {
    tooltip.showAnchor = 1;
    loopCheckAnchor()
    
  }

function toAnchorTwo() {
  tooltip.showAnchor = 2;
  loopCheckAnchor()
}
function toAnchorThree() {
  tooltip.showAnchor = 3;
  loopCheckAnchor()
}

function toUnderLine() {
  const range = quill.getSelection();
  var text = quill.getText(range.index, range.length);
  quill.format("underline", true);
}
//italic
function toItalic() {
  const range = quill.getSelection();
  var text = quill.getText(range.index, range.length);
  quill.format("italic", true);
}

function updateOpenTab(tabContent) {
  if (!tabContent) {
    if (!(tabContent = getActiveTabContent())) return false;
  }

  // DELTA
  if (tabContent.id === "tab-content-delta") {
    // Set delta length (#tab-content-delta > p)
    let p = tabContent.children[0];
    p.innerHTML = "Tamanho Delta: " + quill.getLength();
    p.style.padding = "4px 6px";

    // Set data (#tab-content-delta > pre > code)
    let code = tabContent.children[1].children[0];
    code.innerHTML = JSON.stringify(getContentDelta(), null, 2);

    hljs.highlightBlock(code);
  }
  // TEXT
  if (tabContent.id === "tab-content-text") {
    // #tab-contnet-text > pre > code
    let code = tabContent.children[0].children[0];
    code.innerHTML = getContentText();

    hljs.highlightBlock(code);
  }
  // HTML
  if (tabContent.id === "tab-content-html") {
    // #tab-content-html > pre > code
    let code = tabContent.children[0].children[0];
    code.innerHTML = getContentHTML().replace(/</gi, "&lt;");

    hljs.highlightBlock(code);
  }
}

/** See: https://stackoverflow.com/a/21696585 */
function isHidden(el) {
  if (!el) return true;
  return el.offsetParent === null;
}

function getActiveTabContent() {
  let tabContents = document.querySelectorAll(".tab-content");
  for (let item of tabContents) {
    if (!isHidden(item)) {
      return item;
    }
  }
  return false;
}

function hasClass(element, className) {
  return (" " + element.className + " ").indexOf(" " + className + " ") > -1;
}

// ******************************************************tooltip***************************
class CustomizableTooltip {
  constructor(format, quill, options) {
    // Is everything ok here?
    this.checkState(format, quill);
    this.checkOptions(options);

    // Everything seems ok here...
    this.quill = quill;
    this.format = format;

    // Lets build...
    this.buildInterface();

    var thisTooltip = this;

    this.quill.container.appendChild(this.container);
    this.hide();
    this.showAnchor = 0;
  }

  // This prevents a surprise from appearing while using the editor. If a
  // problem exists, it will appear when the tooltip is being built.
  checkState(format, quill) {
    // Is Quill reference useful?
    if (quill === null || typeof quill !== "object")
      throw "Quill reference was not passed in argument, or is null.";

    // Was the format specified?
    if (!format || format.length <= 0) throw "No format was specified.";

    // Is the format registered?
    if (!Quill.import("formats/" + format))
      throw (
        'No format "' +
        format +
        '" found. Please, be sure to pass a format that is registered within Quill.'
      );
  }

  /** Checks whether properties have been set correctly, or need to be
   * overwritten if not. */
  checkOptions(options) {
    if (!options || options == null) options = {};

    if (!options.inputLabel || options.inputLabel.length <= 0)
      options.inputLabel = "Value";
    if (!options.inputLabelClass || options.inputLabelClass.length <= 0)
      options.inputLabelClass = "rs-tooltip-label";
    if (!options.inputPlaceholer || options.inputPlaceholer.left <= 0)
      options.inputPlaceholer = "Insert value here...";
    if (!options.inputClass || options.inputClass.length <= 0)
      options.inputClass = "rs-tooltip-input";
    if (!options.actionText || options.actionText.length <= 0)
      options.actionText = "Conclude";
    if (!options.actionClass || options.actionClass.length <= 0)
      options.actionClass = "rs-tooltip-action";
    if (!options.containerClass || options.containerClass.length <= 0)
      options.containerClass = "rs-tooltip-container";
    if (!options.hideOnTyping) options.hideOnTyping = false;
    if (
      options.clearAfterHide &&
      options.defaultValue &&
      options.defaultValue.length >= 0
    )
      options.clearAfterHide = false;
    if (!options.hideOnAction || options.hideOnAction == false)
      options.hideOnAction = true;

    this.op = options;
  }

  buildInterface() {
    this.buildContainer();
    // this.buildInputLabel();
    // this.buildInput();
    // this.buildAction();
    this.buildRoles();

    // Adds built elements into this tooltip container.
    // this.container.appendChild(this.inputLabel);
    // this.container.appendChild(this.input);
    // this.container.appendChild(this.action);
    this.container.appendChild(this.roleView);
  }

  buildContainer() {
    var thisTooltip = this;
    var container = document.createElement("DIV");
    container.classList.add(this.op.containerClass);

    // Hide tooltip by clicking outside of it.
    document.body.addEventListener("click", (event) => {
      // Was it clicked off?
      if (!hasClass(event.target, thisTooltip.op.containerClass)) {
        if (
          hasClass(event.target.parentElement, "ql-editor") ||
          event.target.closest(".ql-" + thisTooltip.format)
        ) {
          return;
        }

        thisTooltip.hide();
      }
    });

    // Prevents tooltip from being hidden if its content is clicked.
    container.addEventListener("click", (event) => {
      event.stopPropagation();
    });

    // Hide tooltip when typing text in the editor.
    if (this.op.hideOnTyping) {
      this.quill.on("text-change", function (delta, oldDelta, source) {
        if (source === "user") {
          thisTooltip.hide();
        }
      });
    }

    this.container = container;
  }

  buildInputLabel() {
    var label = document.createElement("SPAN");
    label.innerText = this.op.inputLabel;
    label.classList.add(this.op.inputLabelClass);

    this.inputLabel = label;
  }

  buildInput() {
    var thisTooltip = this;
    var input = document.createElement("INPUT");
    input.type = "text";
    input.classList.add(this.op.inputClass);
    input.placeholder = this.op.inputPlaceholer;
    input.value =
      this.op.defaultValue && this.op.defaultValue.length > 0
        ? this.op.defaultValue
        : "";

    // Has the user added an event of his own to this tooltip? If so, it
    // will be called as a priority.
    if (this.op.onAction && typeof this.op.onAction === "function") {
      input.addEventListener("keydown", (e) => {
        if (e.key === "Enter") {
          this.op.onAction(input.value, e);
          if (thisTooltip.op.hideOnAction) thisTooltip.hide();
        }
      });
    }
    // Otherwise, the tooltip calls the default implementation. It is
    // understood that the user knows how this tooltip works, and has
    // configured it correctly.
    else {
      input.addEventListener("keydown", (e) => {
        if (e.key === "Enter") {
          thisTooltip.insertEmbed(input.value, e);
          if (thisTooltip.op.hideOnAction) thisTooltip.hide();
        }
      });
    }

    this.input = input;
  }

  buildAction() {
    var thisTooltip = this;
    var linkAction = document.createElement("a");
    linkAction.innerText = this.op.actionText;
    linkAction.classList.add(this.op.actionClass);

    // Has the user added an event of his own to this tooltip? If so, it
    // will be called as a priority.
    if (this.op.onAction && typeof this.op.onAction === "function") {
      linkAction.addEventListener("click", (e) => {
        this.op.onAction(thisTooltip.input.value, e);
        if (thisTooltip.op.hideOnAction) thisTooltip.hide();
      });
    }
    // Otherwise, the tooltip calls the default implementation. It is
    // understood that the user knows how this tooltip works, and has
    // configured it correctly.
    else {
      linkAction.addEventListener("click", (e) => {
        thisTooltip.insertEmbed(thisTooltip.input.value, e);
        if (thisTooltip.op.hideOnAction) thisTooltip.hide();
      });
    }

    this.action = linkAction;
  }

  buildRoles() {
    var thisTooltip = this;
    const roleList = document.createElement("ul");
    const roleFirst = document.createElement("li");
    const firstAction = document.createElement("a");
    firstAction.setAttribute("id", 1);
    firstAction.innerText = "吕树";
    firstAction.classList.add("rs-tooltip-action");

    const listener = (e) => {
      const titles = [
        [],
        ["吕树", "phoenix", "吕树-phoenix", "phoenix-吕树"],
        ["吕布", "ken", "吕布-ken", "ken-吕布"],
      ];
      const teams = [
        {
          id: "1",
          role: "吕树",
          cv: "phoenix",
          light: 1,
          color: "red",
        },
        {
          id: "2",
          role: "吕布",
          cv: "ken",
          light: 2,
          color: "blue",
        },
      ];

      const rangeSelection = this.range;

      if (rangeSelection) {
        const delta = quill.getContents(
          rangeSelection.index,
          rangeSelection.length
        );
        const appendContent =
          this.showAnchor > 0 ? titles[e.target.id][this.showAnchor - 1] : "";
        if (delta.ops[0].attributes) {
          const anchorType = delta.ops[0].attributes.anchor;
          console.log("anchorType= " + anchorType);

          if (anchorType === "0") {
            thisTooltip.createAnchorById(
              teams,
              e.target.id,
              this.showAnchor,
              rangeSelection.index,
              rangeSelection.length,
              appendContent
            );
          } else {
            const anchorDelta = quill.getLeaf(rangeSelection.index - 1);
            const existTextLength = anchorDelta[0].text.length;
            const startIndex = rangeSelection.index - anchorDelta[1];
            const content = titles[e.target.id][this.showAnchor - 1];
            quill.updateContents([
              { retain: startIndex - 1 },
              { insert: "[" + content + "]" },
              { delete: existTextLength },
            ]);
          }
        } else {
          thisTooltip.createAnchorById(
            teams,
            e.target.id,
            this.showAnchor,
            rangeSelection.index,
            rangeSelection.length,
            appendContent
          );
        }
      }
      thisTooltip.hide();
    };

    firstAction.addEventListener("click", listener);
    roleFirst.appendChild(firstAction);

    const roleSecond = document.createElement("li");
    const secondAction = document.createElement("a");
    secondAction.innerText = "吕它";
    secondAction.setAttribute("id", 2);
    secondAction.classList.add("rs-tooltip-action");
    secondAction.addEventListener("click", listener);
    roleSecond.appendChild(secondAction);

    const roleThird = document.createElement("li");
    const thirdAction = document.createElement("a");
    thirdAction.innerText = "清除";
    thirdAction.setAttribute("id", 3);
    thirdAction.classList.add("rs-tooltip-action");
    thirdAction.addEventListener("click", listener);
    roleThird.appendChild(thirdAction);

    roleList.appendChild(roleFirst);
    roleList.appendChild(roleSecond);
    roleList.appendChild(roleThird);
    this.roleView = roleList;
  }

  // return amount of append length ,default is zero
  createAnchorById(teams, id, anchor, index, length, appendContent) {
    const contentLength = appendContent.length;
    let appendAmount = 0;
    const team = teams.find((it) => it.id == id);
    if (team) {
      quill.formatText(index, length, "color", team.color);
      quill.formatText(index, length, "id", id);
      quill.formatText(index, length, "anchor", anchor.toString());
      quill.formatText(index, length, "cv", team.cv);
      quill.formatText(index, length, "role", team.role);
      quill.formatText(index, length, "light", team.light);

      if (anchor > 0) {
        quill.insertText(index, "[" + appendContent + "]", {
          color: team.color,
          italic: true,
        });
        appendAmount = appendContent.length + 2;
      }
      return appendAmount;
    }
  }

  toolbarButtonPressed(range) {
    if (this.isVisible()) {
      this.hide();
      return;
    }
    this.range = range;

    this.show();
  }

  // Created for the convenience of client code. Not necessarily this needs to be utilized.
  setInputLabel(label) {
    if (!label || label.length <= 0) return;
    this.inputLabel.innerText = label;
  }

  // Created for the convenience of client code. Not necessarily this needs to be utilized.
  setActionLabel(label) {
    if (!label || label.length <= 0) return;
    this.action.innerText = label;
  }

  // Created for the convenience of client code. Not necessarily this needs to be utilized.
  setInputValue(value) {
    if (!value || value.length <= 0) return;
    this.input.value = value;
  }

  // Created for the convenience of client code. Not necessarily this needs to be utilized.
  setInputPlaceholder(placeholder) {
    if (!placeholder || placeholder.length <= 0) return;
    this.input.placeholder = placeholder;
  }

  // Created for the convenience of client code. Not necessarily this needs to be utilized.
  getInputValue() {
    return this.input.value;
  }

  show() {
    if (this.isVisible()) return;

    this.container.classList.remove("ql-hidden");
    this.updatePosition();

    if (this.op.onShow && typeof onShow === "function") this.op.onShow();
  }

  hide() {
    if (!this.isVisible()) return;

    this.container.classList.add("ql-hidden");

    // if(!this.op.defaultValue && this.op.clearAfterHide) this.input.value = '';
    if (this.op.onHide && typeof onHide === "function") this.op.onHide();
  }

  isVisible() {
    return !hasClass(this.container, "ql-hidden");
  }

  updatePosition() {
    // quill.getBounds return a rectangle based on editor caret position.
    // This is where we can locate where the window will appear. The idea
    // here is to leave the horizontal center of the tooltip aligned with
    // the editor caret (range index).
    let range = this.quill.getSelection();
    const bounds = this.quill.getBounds(range.index);

    // Tooltip left edge X.
    let x = bounds.left - this.container.offsetWidth / 2;
    let editorContainer = document.querySelector(".ql-container");

    // See: http://javascript.info/coordinates
    let leftBorderLimit = editorContainer.getBoundingClientRect().left;
    let rightBorderLimit = editorContainer.getBoundingClientRect().right;

    // Corrects left edge.
    if (x * -1 > leftBorderLimit) {
      x = x + (x * -1 - leftBorderLimit);
    }

    // Tooltip right edge X.
    let widthX = x + this.container.offsetWidth + 2;

    // Corrects right edge.
    if (widthX > rightBorderLimit) {
      x = x - (widthX - rightBorderLimit);
    }

    this.container.style.top =
      bounds.top + // Y from upper left edge.
      bounds.height + // Caret Height (one line).
      10 + // One more small space to not get too on top.
      "px";
    this.container.style.left = x + "px";
  }

  insertEmbed(value, e) {
    if (!value || value.length <= 0) return;

    var range = this.quill.getSelection();
    if (!range)
      range = {
        index: getContentText().length - 1,
        length: 0,
      };

    // Unfortunately this line of code needs to be here. I don't understand
    // why it is necessary to format the URL when adding video as embed, as
    // it should already do this automatically ...
    if (this.format === "video") {
      value = extractVideoUrl(value);
    }

    this.quill.insertEmbed(range.index, this.format, value);
  }
}
//*******************************************************tooltip***************************

// #################################################################################
//                                                                            QUILL
// #################################################################################

let Inline = Quill.import("blots/inline");

/* Try using console.log(...) to find out the call order of each method. */
class TextHighlight extends Inline {
  // Remember, there is:
  // super.formats
  // super.domNode

  static create(value) {
    console.log("Texthighlight: static create(" + value + ")");

    /* I must be careful not passing false as a literal string here 
           because, if I'm not prepared, I may compromise this blot. 
           That's why I pass a false value to super.create. This removes
           any format related to this format (this blot). Do you want to
           check it out? Remove false and pass value as argument, then
           press the clear button (the last button on toolbar).*/
    if (!this.isValueUseful(value)) {
      return super.create(false);
    }

    let node = super.create(value);
    this.setNodeConfigurations(node, value);

    return node;
  }

  static formats(domNode) {
    console.log("Texthighlight: static formats(" + domNode.tagName + ")");
    let data = domNode.getAttribute("data-value");

    // Data is not useful
    if (!this.isValueUseful(data)) {
      return super.formats(domNode);
    }
    // Useful
    else {
      return data;
    }
  }

  /** See: https://github.com/quilljs/parchment#example */
  formats() {
    console.log("Texthighlight: formats()");
    let formats = super.formats();
    let value = TextHighlight.formats(this.domNode);

    // Only defined if the value is correct/acceptable.
    if (TextHighlight.isValueUseful(value)) {
      formats["texthighlight"] = TextHighlight.formats(this.domNode);
    }

    // Return this blot's formats
    return formats;
  }

  format(format, newValue) {
    console.log("Texthighlight: format(" + format + " , " + newValue + ")");
    let oldValue = TextHighlight.formats(this.domNode);

    // Remove
    if (
      !format ||
      format !== TextHighlight.blotName ||
      !TextHighlight.isValueUseful(newValue)
    ) {
      // False = Remove this format
      super.format(format, false);
    }
    // Add
    else {
      let node = this.domNode;
      TextHighlight.setNodeConfigurations(node, newValue, oldValue);
    }
  }

  /* To prevent the node from accidentally being built in different ways. */
  static setNodeConfigurations(node, newValue, oldValue) {
    // Remove previous highlight.
    if (oldValue && this.isValueUseful(oldValue)) {
      node.classList.remove("ql-texthighlight-" + oldValue);
    }

    node.classList.add("ql-texthighlight-" + newValue);
    node.setAttribute("data-value", newValue);
  }

  static isValueUseful(value) {
    if (
      typeof value === "undefined" || // Must be something...
      value === "false" || // Not false as literal string...
      value < 1 || // Not smaller than 1 or...
      value > 5
    ) {
      // Not bigger than 5.
      return false;
    }
    return true;
  }
}

TextHighlight.blotName = "texthighlight";
TextHighlight.tagName = "span";

Quill.register(TextHighlight);
// Does the same as above.
// Quill.register('formats/texthighlight' , TextHighlight);

/** See: https://quilljs.com/docs/api/#getcontents */
function getContentDelta() {
  return quill.getContents();
}

/** See: https://github.com/quilljs/quill/issues/2698 */
function getContentText() {
  return quill.getContents().ops.reduce((text, op) => {
    if (typeof op.insert === "string") {
      return text + op.insert;
    }
    // If it is not a string, the newline character is set, which has
    // a length of only 1 character.
    else {
      return text + "\n";
    }
  }, "");
}

/** See: https://github.com/quilljs/quill/issues/903#issuecomment-243844178 */
function getContentHTML() {
  return quill.root.innerHTML;
}

// #################################################################################
//                                                                        HIGHLIGHT
// #################################################################################

function highlightSelectedText(hl) {
  // Is hl (highlight) a value between 0 and 5 (inclusive)?
  if (hl < 0 || hl > 5) return false;
  /* Filters which elements can be highlighted. There is a list that contains
       only the elements that can be highlighted. This check also allows highlights
       to be removed even when the selection contains elements that cannot be 
       highlighted (hl> 0, because 0 clears any highlight).*/
  // if (!isHighlightPermited() && hl > 0) return false;

  var range = quill.getSelection();

  // Check selection...
  if (range && range.length > 0) {
    console.log("hl= " + hl);
    // Add
    if (hl > 0) {
      console.log(
        "ADD - [hl: " +
          hl +
          ", in: " +
          range.index +
          ", le: " +
          range.length +
          "]"
      );
      quill.format("texthighlight", hl);
    }
    // Remove
    else {
      console.log(
        "REMOVE - [hl: " +
          hl +
          ", in: " +
          range.index +
          ", le: " +
          range.length +
          "]"
      );
      quill.format("texthighlight", false);
    }
  }
}

/** This is not currently working. Try to select 2 paragraphs. */
function isHighlightPermited() {
  let el = getSelectionTextAndContainerElement().containerElement;
  let whitelist = ["P", "LI", "A"];

  if (whitelist.indexOf(el.tagName) != -1) {
    return true;
  }

  return false;
}

/** See: https://stackoverflow.com/a/4637223/2910546 */
function getSelectionTextAndContainerElement() {
  var text = "",
    containerElement = null;
  if (typeof window.getSelection != "undefined") {
    var sel = window.getSelection();
    if (sel.rangeCount) {
      var node = sel.getRangeAt(0).commonAncestorContainer;
      containerElement = node.nodeType == 1 ? node : node.parentNode;
      text = sel.toString();
    }
  } else if (
    typeof document.selection != "undefined" &&
    document.selection.type != "Control"
  ) {
    var textRange = document.selection.createRange();
    containerElement = textRange.parentElement();
    text = textRange.text;
  }
  return {
    text: text,
    containerElement: containerElement,
  };
}

// #################################################################################
//                                                                             MAIN
// #################################################################################

$(document).ready(function () {
  /* The toolbar module is responsible for adding a listener to the events of
       it's controls (buttons and selects). This means that it is responsible for
       calling the appropriate handler (if present), as well as passing the value
       of the argument. For buttons, the value of the argument is obtained through
       the value="..." attribute of the html <button> element. For select (dropdowns),
       the value will be the same as the selected="..." attribute defined in the html 
       <select> element.*/

  var toolbarOptions = {
    container: "#toolbar-container",
    handlers: {
      texthighlight: function (value) {
        highlightSelectedText(value);
      },
    },
  };

  // var quill = new Quill('#editor', {
  //   modules: {
  //     toolbar: toolbarOptions_2
  //   }
  // });

  // Handlers can also be added post initialization
  // var toolbar = quill.getModule('toolbar');
  // toolbar.addHandler('image', showImageUI);

  var quill = new Quill("#editor", {
    modules: {
      toolbar: [
        [{ 'color': [] }, { 'background': [] }] // 定义工具栏
      ]
    },
    theme: 'snow'
  });

  window.quill = quill;

  var tooltip = new CustomizableTooltip("image", quill, {
    inputLabel: "Image:",
    inputPlaceholer: "Image URL...",
    actionText: "Insert",
    hideOnTyping: true,
    clearAfterHide: true,
  });

  window.tooltip = tooltip;

  // Open default tab. See: https://www.w3schools.com/howto/howto_js_tabs.asp
  const defualtTab = document.getElementById("default-tab-button");
  defualtTab.click();

  // Quill content alteration.
  quill.on("text-change", function (delta, oldDelta, source) {
    updateOpenTab();
  });

  // Checkbox
  const checkRO = document.getElementById("input-check-readonly");
  checkRO.addEventListener("click", () => {
    quill.enable(!checkRO.checked);
  });

  //------------------------blot
  const BlockEmbed = Quill.import("blots/block/embed");
  // 定义新的blot类型
  class AppPanelEmbed extends BlockEmbed {
    static create(value) {
      const node = super.create(value);
      node.setAttribute("contenteditable", "false");
      node.setAttribute("width", "100%");
      //   设置自定义html
      node.innerHTML = this.transformValue(value);
      console.log("create");
      return node;
    }

    static transformValue(value) {
      let handleArr = value.split("\n");
      handleArr = handleArr.map((e) =>
        e.replace(/^[\s]+/, "").replace(/[\s]+$/, "")
      );
      return handleArr.join("");
    }

    // 返回节点自身的value值 用于撤销操作
    static value(node) {
      return node.innerHTML;
    }
  }
  // blotName
  AppPanelEmbed.blotName = "AppPanelEmbed";
  // class名将用于匹配blot名称
  AppPanelEmbed.className = "embed-innerApp";
  // 标签类型自定义
  AppPanelEmbed.tagName = "div";
  Quill.register(AppPanelEmbed, true);
  //------------------------blot end

  //------------------------attribute
  var FontAttributor = Quill.import("attributors/class/font");
  FontAttributor.whitelist = [
    "sofia",
    "slabo",
    "roboto",
    "inconsolata",
    "ubuntu",
  ];
  Quill.register(FontAttributor, true);

  var SizeStyle = Quill.import("attributors/style/size");
  SizeStyle.whitelist = ["10px", "20px", "50px"];
  Quill.register(SizeStyle, true);

  const Parchment = Quill.import("parchment");

  //----------attribute id-----------------------------------
  class IdAttributor extends Parchment.Attributor.Class {}
  const IdtStyle = new IdAttributor("id", "ql-id", {
    scope: Parchment.Scope.INLINE,
  });
  Quill.register({ "formats/id": IdtStyle }, true);
  //----------attribute id-----------------------------------

  //----------attribute cv-----------------------------------
  class CvAttributor extends Parchment.Attributor.Class {}
  const cvStyle = new CvAttributor("cv", "ql-cv", {
    scope: Parchment.Scope.INLINE,
  });
  Quill.register({ "formats/cv": cvStyle }, true);
  //----------attribute id-----------------------------------

  //----------attribute role-----------------------------------
  class RoleAttributor extends Parchment.Attributor.Class {}
  const roleStyle = new RoleAttributor("role", "ql-role", {
    scope: Parchment.Scope.INLINE,
  });
  Quill.register({ "formats/role": roleStyle }, true);
  //----------attribute role-----------------------------------

  //----------attribute role-----------------------------------
  class lightAttributor extends Parchment.Attributor.Class {}
  const lightStyle = new lightAttributor("light", "ql-light", {
    scope: Parchment.Scope.INLINE,
  });
  Quill.register({ "formats/light": lightStyle }, true);
  //----------attribute role-----------------------------------

  //----------attribute anchor-----------------------------------
  class anchorAttributor extends Parchment.Attributor.Class {}
  const anchorStyle = new anchorAttributor("anchor", "ql-anchor", {
    scope: Parchment.Scope.INLINE,
  });
  Quill.register({ "formats/anchor": anchorStyle }, true);
  //----------attribute anchor-----------------------------------

  quill.on("selection-change", function (range, oldRange, source) {
    if (range) {
      if (range.length == 0) {
        console.log(
          "User cursor is on",
          range.index,
          quill.getLine(range.index)[1],
          quill.getLine(range.index)[0].children.head.text,
          "----",
          quill.getLine(range.index)[0].children.tail.text
        );
        const duan = quill.getLeaf(range.index)[0].text; //quill.getLine(range.index)[0].children.head.text
        const curr = quill.getLeaf(range.index)[1];
        console.log(
          "leaf text= " +
            quill.getLeaf(range.index)[0].text +
            " >>> " +
            quill.getLeaf(range.index)[0].attribute
        );
        const leftContent = duan.substring(0, curr);
        const leftStartIndex = leftContent.lastIndexOf("“");
        const leftEndIndex = leftContent.lastIndexOf("”");
        const rightContent = duan.substring(curr);
        let rightStartIndex = rightContent.indexOf("“");
        if (rightStartIndex === -1) rightStartIndex = rightContent.length;
        const rightEndIndex = rightContent.indexOf("”");
        if (
          leftStartIndex > leftEndIndex &&
          rightEndIndex < rightStartIndex &&
          leftStartIndex < curr < rightEndIndex
        ) {
          quill.setSelection(
            range.index + (leftStartIndex - curr),
            rightEndIndex - leftStartIndex + curr + 1
          );
        } else {
          tooltip.hide();
        }
      } else {
        var text = quill.getText(range.index, range.length);
        console.log("User has highlighted", text);
        if (source == "api") {
          tooltip.toolbarButtonPressed(range);
        }
      }
    } else {
      console.log("Cursor not in the editor");
    }
  });
});
